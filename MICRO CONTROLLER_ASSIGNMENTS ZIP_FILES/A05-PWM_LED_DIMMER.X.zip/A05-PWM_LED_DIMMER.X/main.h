/* 
 * File:   main.h
 * Author: vetri
 *
 * Created on September 3, 2022, 8:16 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY       PORTD
#define LED_ARRAY_DDR   TRISD
#define LED1	RD0
#define ON      1
#define OFF     0

#endif	/* MAIN_H */

