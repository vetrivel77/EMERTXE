/*
 * Name : VETRIVEL.P
 * Date : 25/08/2022
 * Description : A02-Implement pattern generator on LED'S controlled by switches 
 */

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF  

static void init_config(void) {
    /*To keep all LEDS OFF */
    LED_ARRAY_1 = OFF;
    
    /*To configure PORTD as output PORT*/
    LED_ARRAY_1_DDR = 0x00; 
    
    /* Initializing digital keypad */
    init_digital_keypad();

}
void main(void) {
    //Variable declaration
    unsigned char key, key_copy;
    
    init_config();

    while (1) {
        
        /*To read key press*/
        key = read_digital_keypad(LEVEL);
        
        /*If switch is pressed, then only update key_copy*/
        if (key != ALL_RELEASED)
        {
            key_copy = key;
        }
        glow_on_press(key_copy);
    }
    return;
}
void glow_on_press(unsigned char key)
{  
    /*variable declaration*/
    unsigned char static flag = 0;
    static unsigned int long delay = 10000;
    static unsigned int i=0,j=0,k=0;
    
    /*using non blocking delay*/
    if( delay++ == 10000)       
    {           
        delay = 0;
        flag = !flag;  
        /*top to bottom and bottom to top LED'S blinking*/
        if(key == SW1)       
        {                              
            //The LEDs should glow from Left to Right and Right to left .                           
            /*Turn on LED'S from top to bottom */                            
            if( i < 8)                           
            {                                     
                LED_ARRAY_1 = LED_ARRAY_1 | (1 << i);                                                                                                
                i++;                                                          
            }                   
            /*Turn off LED'S from bottom to top */                 
            else if(i >= 8 && i < 16)                          
            {                                                                                                                                                      
                LED_ARRAY_1 = LED_ARRAY_1 & ~(1 << (i - 8));                                                                                                                                                                        
                i++;                                                                 
            }                    
            /*Turn on LED'S from bottom to top */                   
            else if(j <= 8)                          
            {                                     
                LED_ARRAY_1 = LED_ARRAY_1 | (1 << (8 - j));                         
                j++;                        
            }       
            /*Turn off LED'S from bottom to top */     
            else if(j > 8 && j <= 16)        
            {                                                                              
                LED_ARRAY_1 = LED_ARRAY_1 & ~(1 << (16 - j));                                                 
                j++;                                          
            }
            /*output LEDS'S are continues running until user pressed another key*/        
            if(i == 16 && j == 17)
            {
                i=0;
                j=0; 
            }

        }
        /*top to bottom  LED'S blinking*/
        else if(key == SW2)        
        {               
            //The LEDs should glow from left to Right and switch off from left to right, no direction control/ direction change       
            /*Turn on LED'S from top to bottom */           
           
            if( k < 8)       
            {           
                LED_ARRAY_1 = LED_ARRAY_1 | (1 << k);                                                                      
                k++;                                       
            } 
            /*Turn off LED'S from bottom to top */
            else if(k >= 8 && k < 16)        
            {                                                                                                                             
                LED_ARRAY_1 = LED_ARRAY_1 & ~(1 << (k - 8));                                                                                                                                              
                k++;                                              
            } 
            /*output LEDS'S are continues running until user pressed another key*/  
            if(k == 16)
            {
                k=0;
            }
        } 
        /*Alternative LED'S blinking*/
        else if(key == SW3)   
        {             
            //The LEDs should blink alternately
            /*using flag value to reinitialize the LED_ARRAY_1 value */
            if(flag)
            {
                LED_ARRAY_1 = 0xAA;
            }
            else 
            {
                LED_ARRAY_1 = ~LED_ARRAY_1 ;   
            }
        }
        /*Nibble LEDI'S blinking*/
        else if( key == SW4)  
        {       
            //The LEDs has to blink nibble wise, i.e first 4 LEDs will be ON, next 4 LEDs will be OFF,        
            //after first 4 LEDs will be OFF, next 4 LEDs will be ON. 
            /*using flag value to reinitialize the LED_ARRAY_1 value */
            if(flag)                                
            {    
                LED_ARRAY_1 = 0x0F;	 
            }
            else 
            {
                LED_ARRAY_1 = ~LED_ARRAY_1 ;              
            }
            
        }
        /*user pressed above SW4 whether turn off the LED'S*/
        else
        {
            LED_ARRAY_1 = OFF;
        }
    }

}
