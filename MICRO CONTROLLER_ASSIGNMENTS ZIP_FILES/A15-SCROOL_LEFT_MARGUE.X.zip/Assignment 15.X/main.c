/* Name: VETRIVEL P
 * DATE : 18/09/2022
 * DESCRIPTION: A15-Implement a left scrolling number marquee
*/

#include <xc.h>
#include "ssd.h"

#pragma config WDTE = OFF     /* Watchdog Timer Enable bit (WDT disabled)*/

static void init_config(void) {
    /*intilization of  ssd*/
    init_ssd();
}
void main(void) {
    /*intilization Digit and ssd values*/       
    unsigned char ssd[MAX_SSD_CNT]; 
    init_config();
    unsigned int digit[]={ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, UNDERSCORE, UNDERSCORE};
    unsigned int wait=0, count = 0;
    while (1)
    {
        if( wait++ == 200)
        {
            wait = 0;
            if(count++ >= 11)
            {
                count = 0;
            }
        }
        ssd[0] = digit[count];
        ssd[1] = digit[(count + 1)%12];
        ssd[2] = digit[(count + 2)%12];
        ssd[3] = digit[(count + 3)%12];
        
        display(ssd);
        
    }
    return;
}
