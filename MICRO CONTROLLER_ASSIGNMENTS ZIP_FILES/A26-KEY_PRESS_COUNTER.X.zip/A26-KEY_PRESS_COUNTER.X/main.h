/* 
 * File:   main.h
 * Author: vetri
 *
 * Created on September 22, 2022, 10:18 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

