/* 
 * Name : VETRIVEL P
 * DATE : 22/09/2022
 * Description: Implement a 10-digit up counter 
 */

#include <xc.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_clcd();
    
}

void main(void) {
    init_config();
    char str[]  = "0000000000";    
    static unsigned int i = 9, wait = 50000, j = 0;
    char inc = '0';
    clcd_print("Up counter", LINE1(0));
    clcd_print("count:", LINE2(0));
    while (1) 
    {
        /*value automatically increased*/
        if(wait++ == 50000 )
        {
            wait = 0;
            clcd_print(str, LINE2(6));              
            str[9]++;
            for(int j = 9; j >= 0; j--)
            {
                if(str[j] == ':' )
                {
                    str[j-1]++;
                    str[j] = '0';
                }
            }                                   
        }
    }    
    return;
}
