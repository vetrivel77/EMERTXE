/*
 * NAME : VETRIVEL P
 * DATE : 07/10/2022
 * DESCRIPTION : A10-Implement a 4 digit down counter with variable frequency
 */

#include <xc.h>
#include "ssd.h"
#include "adc.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF

#define _XTAL_FREQ  200000

static unsigned int wait = 0,delay = 0 ;
void delay_speed(unsigned short adc_reg_val)          /* vary speed of display */
{
    wait = 0;
    delay = (500/adc_reg_val)/10;
}

/*configuring display and ssd*/
void init_config(void)
{
	init_ssd();
	init_digital_keypad();
    init_adc();
}

void main(void)
{
    unsigned short adc_reg_val; //0 to 1023
    static unsigned char ssd[MAX_SSD_CNT];
    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};/* array for numbers 1-9*/
	init_config();

    unsigned int count = 9999;        
	while(1)
	{
	
        adc_reg_val = read_adc(); //10 bits -> 0 to 1023
       
        ssd[3] = digit[count % 10];             
	    ssd[2] = digit[(count % 100)/10];
		ssd[1] = digit[(count % 1000)/100];
		ssd[0] = digit[count / 1000];
        display(ssd);             
        /* to vary speed of count down as varying potentiometer value */
        delay_speed(adc_reg_val/10);      
        /* vary display speed in ssd, vary the speed of count value change */        
        if(wait++ == delay)             
        {
            wait = 0;
            count--;
        }
        if(count == 0)
        {
            count = 9999;
        }
    
    }

}