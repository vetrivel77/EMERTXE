#include "sll.h"

int sl_sort(Slist **head)
{
     int flag = 0;
    //check if list is empty or not
    if(*head == NULL)
    {
        return LIST_EMPTY;
    }
    //check if list has only one element
    if((*head)->link == NULL)
    {
        return SUCCESS;
    }
    do
    {
        //create a prev ptr pointing to null
        Slist *prev = NULL;
        //create a current ptr pointing to head
        Slist *current = *head;
        //create a next ptr which holds the address of current
        Slist *next = current->link;
        flag = 0;
        //when next not equal to null  till the point continue
        while(next != NULL)
        {
            //data compare
            if( current->data  >  next->data )
            {
                //set flag to 1
                flag = 1;
                //when prev != null then swap
                if( prev != NULL )
                {
                    Slist *temp = next->link;
                    prev->link = next;
                    next->link = current;
                    current->link = temp;
                }
                else
                {
                    //else swap by assigning next in head
                    Slist *temp = next->link;
                    *head = next;
                    next->link = current;
                    current->link = temp;
                }
                //increment point or point to next pointer
                prev = next;
                next = current->link;
            }
            else
            {
                //increment point or point to next pointer
                prev = current ;
                current = next ;
                next = next->link;
            }
        }

    }while(flag > 0);
    return  SUCCESS;
}