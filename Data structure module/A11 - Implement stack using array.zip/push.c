#include "stack.h"

/* Fuction for inserting the element */
int Push(Stack_t *s, int element)
{
    // check stack is full or not
if(s->top == s->capacity-1)
return FAILURE;
//stack point 0th index
/*if(s->top == -1)
s->top = 0;*/
s->top++;
// insert data to stack
s->stack[s->top] = element;

return SUCCESS;

}