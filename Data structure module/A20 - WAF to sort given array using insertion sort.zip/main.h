#ifndef MAIN_H
#define MAIN_H
    
#include<stdio.h>

typedef int data_t;

data_t insertion(data_t *arr, data_t size);

#endif
