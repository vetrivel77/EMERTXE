#include "main.h"

  
/* Function to sort the array using heap sort */
int heap_sort(int *heap, int size )
{
    // Heap sort
    int i;
    for (i = size - 1; i >= 0; i--) 
    {
      swap(&heap[0], &heap[i]);
  
      // Heapify root element to get highest element at root again
      max_heap(heap, 0, i);
    }
    return 0;
}       
