#include "main.h"

void build_maxheap(int *heap, int size)
{
    // Build max heap
    int i;
    for (i = size / 2 - 1; i >= 0; i--)
      max_heap(heap, i, size);
}