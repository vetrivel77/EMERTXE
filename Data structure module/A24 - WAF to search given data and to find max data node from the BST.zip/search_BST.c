#include "tree.h"

/* Iteratively */
int search_BST(Tree_t * root, int data)
{
    //check if tree is empty
    if(root == NULL)
    {
        return FAILURE;
    }
    //if not empty, then create temp reference ptr to traverse the tree
    Tree_t *temp = root;
    while(temp)
    {
        if(temp -> data != data)
        {
            //if leaf node is reached with no element match
            if(temp -> left == NULL && temp -> right == NULL)
            {
                return NOELEMENT;
            }
            if(temp -> data < data)
            {
                //search in right side of the tree
                temp = temp -> right;
            }
            else
            {
                //search in left side of the tree
                temp = temp -> left;
            }
            
        }
        else if(temp -> data == data)
        {
            return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    return FAILURE;
}