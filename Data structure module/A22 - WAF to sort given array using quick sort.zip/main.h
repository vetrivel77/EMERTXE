#ifndef MAIN_H
#define MAIN_L

#include <stdio.h>

int quick_sort(int *, int, int );
int partition(int *, int , int );

#endif
