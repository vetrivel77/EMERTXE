#include "tree.h"

int findmin(Tree_t * root)
{
     if(root == NULL)
     {
		return FAILURE;
     }

	//if non empty take one local reference ptr to traverse along the tree nodes
	Tree_t *temp;
	temp = (root);

	//go to left most element
	while(temp -> left != NULL)
	{
		temp = temp -> left;
	}
	return temp -> data;
    
}
