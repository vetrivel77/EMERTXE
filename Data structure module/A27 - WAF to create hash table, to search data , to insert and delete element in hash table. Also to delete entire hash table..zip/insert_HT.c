#include"hash.h"

int insert_HT(hash_t *arr, int data, int size)
{
    //calculate index using hash function
    int index = data % size;
    
	if(arr[index].value == -1)
	{
	    //We only need to update value
		arr[index].value = data;
		return SUCCESS;
	}
    // Create the new node
	hash_t *new = malloc(sizeof(hash_t));
    //if element is null
	if(new == NULL)
	{
		return FAILURE;
	}
    // update value and link part
	new->index = index;
	new->value = data;
	new->link = NULL;
    //if link is null
	if(arr[index].link == NULL)
	{
		arr[index].link = new;
		return SUCCESS;
	}
    //create local reference to traverse
	hash_t *temp = arr[index].link;
    //move in array until an empty
	while(temp->link)
	{
		temp = temp->link;
	}
	//update link prt to new
	temp->link = new;
	return SUCCESS;
}