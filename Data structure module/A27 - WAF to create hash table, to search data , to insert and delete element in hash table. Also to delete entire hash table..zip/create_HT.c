#include "hash.h"
//function to create hash table
void create_HT(hash_t *HT, int size)
{
    int index;
    //for loop to iterate upto size
    for(int i = 0; i < size; i++)
    {
        HT[i].index = index;
        HT[i].value = -1;
        HT[i].link = NULL;
    }
}