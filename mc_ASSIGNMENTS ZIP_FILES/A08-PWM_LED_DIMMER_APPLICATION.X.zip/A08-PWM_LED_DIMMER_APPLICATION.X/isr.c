#include <xc.h>
#include "main.h"

extern unsigned short adc_reg_val;         
void __interrupt() isr(void)
{      
    static unsigned long int period = 100, loop_counter = 0, duty_cycle = 50;  

    if (TMR0IF == 1)
    {
        TMR0 = TMR0 + 8;         
        /*LED blinking was increasing when we are increasing the Nobe in pot meter*/          
        /*Pot meter is 0to1023 until slowly brightness increasing*/     
        if(loop_counter < adc_reg_val/10)		                        
        {			               
            LED1 = ON;		            
        }		          
        else if(loop_counter >= adc_reg_val/10 && loop_counter < period )		                
        {						                
            LED1 = OFF;		          
        }			       
        if(loop_counter++ == period)		            
        {		                 
            loop_counter = 0;		           
        }      
        TMR0IF = 0;       
    }
}