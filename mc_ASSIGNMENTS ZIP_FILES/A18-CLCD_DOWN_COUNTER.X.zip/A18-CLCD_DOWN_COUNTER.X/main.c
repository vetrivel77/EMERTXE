/*
 * NAME : VETRIVEL P
 * DATE: 22/09/2022
 * DESCRIPTION: Implement a 10 digit down counter
 */

#include <xc.h>
#include <string.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)


static void init_config(void) {
    init_clcd();
}

void main(void) {
    
    init_config();   
    char msg[] = "9999999999";
	unsigned long wait = 0;
	int i = 0 ;
	char temp ;

    while (1) {
            
		if ( wait++ == 50000 )
		{           
			wait = 0;
            /*printing on the display*/
            clcd_print("Down counter", LINE1(0));
            clcd_print( "Count:", LINE2(0));
			clcd_print( msg, LINE2(6));
            
			/* to decrement  counter by 1 */
			msg[9] = msg[9] - 1;
			if ( msg[9] == 47 )
			{
				int index = 9;
				do
				{
					msg[index] = '9';
					index--;
					msg[index] = msg[index]-1;
				}while( msg[index] == 47 && index >=0 );

			}
		
        }

       
    }
    return;
}
