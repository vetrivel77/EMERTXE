/* 
 * Name : VETRIVEL P
 * Date : 19/09/2022
 * Description: A12 - Implement a Timer Down Count
 * 
 */


#include <xc.h>
#include "ssd.h"
#include "timers.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static unsigned char ssd[MAX_SSD_CNT]= {ZERO, ZERO, ZERO, ZERO};
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
int change, change1;

void init_config(void)
{
	/* to initialize ssd, digital keypad and timer0 */
	init_ssd();
	init_digital_keypad();
	init_timer0();
    init_timer2();
    PEIE = 1;
    GIE = 1;
}
void main(void)
{
	init_config();
    short int min = 0, sec = 0, hr = 0;
	unsigned char key , cur_key = SW3;
	int pos = -1, once = 1;
	char update = 0;
	char u_type = 0;

	while( 1 )
	{
		key = read_digital_keypad(STATE);
        if(key != ALL_RELEASED)
        {
            cur_key = key;
        }
		/* to perfrom action pressing keys 
		 * to start if key 4 pressed
		 * if clock in stop mode then only if key 1, 2, 3 pressed
		 * if key 3 pressed select the postion
		 * if key 1 pressed up count current postion
		 * id key 2 pressed down count current postion
		 */
        if(once == 1)
        {
            key = SW3;
            cur_key = SW3;
            once = 0;
            pos = -1;
        }
        /*increase the count*/
        if( key == SW1 && (TMR0IE == 0) )
		{
			update = 1 ;
			u_type = 1;
		}
         /*decrease the count*/
		else if( key == SW2 && (TMR0IE == 0) )
		{
			update = 1;
			u_type = 0;
            if(min == 0)
            {
                min = 99;
                min++;
            }
            if(sec == 0 )
            {
                sec = 59;
                sec++;
            }

		}
         /*select position*/
		else if( key == SW3 && (TMR0IE == 0) )
		{
			pos = pos + 1;
            if(pos > 1)
                pos = 0;
		}    
		else if ( key == SW4 )
		{
			TMR0IE = 1;
            TMR2IE = 0;
       
            /* Switching on the Timer2 */
            TMR2ON = 0;
            	ssd[1] = ssd[1] | DOT;
		}
              
		/* if key 1, 2 pressed to up/down count the current postion */
		if ( update )
		{
			switch ( pos )
			{
				case 0 :
					sec  = (u_type) ? sec + 1 : sec - 1;
					break;
				
				case 1 :
					min  = (u_type) ? min + 1 : min - 1;
					break;
			}

			if ( sec > 59  || sec <= 0)
				sec = 0;

			if ( min > 100 || min <= 0)
				min = 0;
            update = 0;
        }
        if(change1 == 1)
        {
           
            if((cur_key == SW1 || cur_key == SW2 ||cur_key == SW3) && (TMR0IE == 0))
            {
               
                    ssd[3] = digit[sec%10];
                    ssd[2] = digit[sec/10];
                    ssd[1] = digit[min%10];
                    ssd[0] = digit[min/10];
                    
               
            }
            ssd[1] = ssd[1] | DOT;
            
        }
        if(change1 == 2)
        {
            change1 = 0;
            if((cur_key == SW1 || cur_key == SW2 ||cur_key == SW3 )&& (TMR0IE == 0))
            {
                if(pos == 0)
                {
                    ssd[3] = 0x00;
                    ssd[2] = 0x00;
                    ssd[1] = digit[min%10];
                    ssd[0] = digit[min/10];
                    
                }
                else if(pos == 1)
                {
                    ssd[1] = 0x00;
                    ssd[0] = 0x00;
                    ssd[3] = digit[sec%10];
                    ssd[2] = digit[sec/10];
                }

            }
	
		}
		/* if clock is in run mode */
		if ( TMR0IE )
		{                      
			// for every half sec change dot blinking;
			if ( change == 1 )
				ssd[1] = ssd[1] | DOT;
			// for every one sec chanage sec value
			if( change == 2 )
			{

				change = 0;
				sec--;
				if ( sec <= 0 )
				{
					sec = 59;
					min--;
				}
				if( min == -1)
                {
					min = 0;
                    sec = 0;
                    
                }
                if(min == 0 && sec == 0)
                {
                    TMR0IE = 0;
                    TMR2IE = 1;
       
                    /* Switching on the Timer2 */
                    
                    TMR2ON = 1;
                    once = 1;
                }                             
                ssd[3] = digit[sec%10];
                ssd[2] = digit[sec/10];
                ssd[1] = digit[min%10];
                ssd[0] = digit[min/10];              
			}
		}
		display(ssd);
	}
}
