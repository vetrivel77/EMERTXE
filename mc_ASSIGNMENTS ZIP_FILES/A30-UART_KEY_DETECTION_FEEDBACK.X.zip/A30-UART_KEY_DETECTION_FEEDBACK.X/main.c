/*
 * NAME: VETRIVEL P
 * DATE: 29/09/2022
 * DESCRIPTION : A30 - Implement a key detection feedback using UART
 */

#include <xc.h>
#include "uart.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void)
{       
    init_uart(9600); // COMMON BAUD RATE
    init_digital_keypad();
    puts("UART Test Code\n");    
}

void main(void) {
    unsigned long int wait = 0;
    unsigned char key;
    init_config();

    while (1) {
        /*READ KEY FROM USER*/
        key = read_digital_keypad(LEVEL);
        
       /* With respect to key press 
        * printing output in cute-com serial terminal         
        */
        // using non blocking delay to avoiding bouncing effect
        if(wait-- == 0)
        {
            wait =1000;
        }
        if(key == SW1)
        {
            puts("Switch 1 is Pressed\n");
        }
        else if(key == SW2)
        {
            puts("Switch 2 is Pressed\n");
        }
        else if(key == SW3)
        {
            puts("Switch 3 is Pressed\n");
        }
        else if(key == SW4)
        {
            puts("Switch 4 is Pressed\n");
        }
        
    }   
    return;
}
