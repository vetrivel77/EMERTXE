/* 
 * File:   main.h
 * Author: vetri
 *
 * Created on September 3, 2022, 8:16 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY       PORTD
#define LED_ARRAY_DDR   TRISD

#define LED_ARRAY_1       PORTB
#define LED_ARRAY_DDR_1   TRISB
#define LED1	RB7
#define ON      1
#define OFF     0

#endif	/* MAIN_H */

